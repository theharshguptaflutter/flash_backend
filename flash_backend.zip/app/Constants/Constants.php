<?php

// SERVER Paths

// Local Public Puth
//define('PUBLIC_PATH', 'http://localhost/flash-backend/public/');

// For Live server
define('PUBLIC_PATH', 'https://flashappza.com/');
// ========================================================================